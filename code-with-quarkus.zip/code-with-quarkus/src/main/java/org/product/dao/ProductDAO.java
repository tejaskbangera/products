package org.product.dao;

import java.util.List;
import java.util.Optional;

import org.product.entity.Product;

public interface ProductDAO {
	
	Product save(Product p);

	Optional<Product> findById(Integer id);

	List<Product> findAll();

	List<Product> findAllOrderByPriceJpql();

	List<Product> findAllOrderByPriceNative();

	void deleteById(Integer id);
}
