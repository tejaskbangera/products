package org.product.service;

import java.util.List;

import org.product.entity.Product;

public interface ProductService {
	
	Product create(Product p);

	Product update(Integer id, Product p);

	Product get(Integer id);

	List<Product> list();

	void delete(Integer id);

	boolean isAvailable(Integer id, int count);

	List<Product> listByPriceAsc(boolean useNativeSql);
}
