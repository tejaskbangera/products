package org.product.controller;

import org.product.entity.Product;
import org.product.service.ProductService;
import java.net.URI;
import java.util.List;
import java.util.Map;

import jakarta.ws.rs.core.MediaType;
import jakarta.inject.Inject;
import jakarta.validation.Valid;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

@Path("/api/products")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ProductResource {

	@Inject
	ProductService service;

	@POST
	public Response create(@Valid Product p) {
		Product created = service.create(p);
		return Response.created(URI.create("/api/products/" + created.getId())).entity(created).build();
	}

	@GET
	public List<Product> list() {
		return service.list();
	}

	@GET
	@Path("/{id}")
	public Product get(@PathParam("id") Integer id) {
		return service.get(id);
	}

	@PUT
	@Path("/{id}")
	public Product update(@PathParam("id") Integer id, @Valid Product p) {
		return service.update(id, p);
	}

	@DELETE
	@Path("/{id}")
	public Response delete(@PathParam("id") Integer id) {
		service.delete(id);
		return Response.noContent().build();
	}

// Availability: /api/products/{id}/availability?count=5
	@GET
	@Path("/{id}/availability")
	public Map<String, Object> availability(@PathParam("id") Integer id,
			@QueryParam("count")int count) {
		boolean available = service.isAvailable(id, count);
		return Map.of("productId", id, "requested", count, "available", available);
	}

// Sort by price asc; toggle native SQL via query param
	@GET
	@Path("/sorted/by-price")
	public List<Product> byPrice(@QueryParam("native") boolean useNativeSql) {
		return service.listByPriceAsc(useNativeSql);
	}
}