package org.product.serviceimplementation;

import java.util.List;

import org.product.dao.ProductDAO;
import org.product.entity.Product;
import org.product.service.ProductService;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.NotFoundException;

public class ProductServiceImpl implements ProductService {

	@Inject
	ProductDAO dao;

	@Override
	@Transactional
	public Product create(Product p) {
		return dao.save(p);
	}

	@Override
	@Transactional
	public Product update(Integer id, Product p) {
		Product existing = dao.findById(id)
				.orElseThrow(() -> new NotFoundException("Product %d not found".formatted(id)));
		existing.setName(p.getName());
		existing.setDescription(p.getDescription());
		existing.setPrice(p.getPrice());
		existing.setQuantity(p.getQuantity());
		return dao.save(existing);
	}

	@Override
	public Product get(Integer id) {
		return dao.findById(id).orElseThrow(() -> new NotFoundException("Product %d not found".formatted(id)));
	}

	@Override
	public List<Product> list() {
		return dao.findAll();
	}

	@Override
	@Transactional
	public void delete(Integer id) {
		dao.deleteById(id);
	}

	@Override
	public boolean isAvailable(Integer id, int count) {
		Product p = get(id);
		return p.getQuantity() != null && p.getQuantity() >= count;
	}

	@Override
	public List<Product> listByPriceAsc(boolean useNativeSql) {
		return useNativeSql ? dao.findAllOrderByPriceNative() : dao.findAllOrderByPriceJpql();
	}
}
