package org.product.daoimplementation;

import java.util.List;
import java.util.Optional;

import org.product.dao.ProductDAO;
import org.product.entity.Product;

import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;

public class ProductDAOImpl implements ProductDAO {

	@Inject
	EntityManager em;

	@Override
	@Transactional
	public Product save(Product p) {
		if (p.getId() == null) {
			em.persist(p);
			return p;
		} else {
			return em.merge(p);
		}
	}

	@Override
	public Optional<Product> findById(Integer id) {
		return Optional.ofNullable(em.find(Product.class, id));
	}

	@Override
	public List<Product> findAll() {
		return em.createQuery("SELECT p FROM Product p", Product.class).getResultList();
	}

	@Override
	public List<Product> findAllOrderByPriceJpql() {
		return em.createNamedQuery("Product.findAllOrderByPrice", Product.class).getResultList();
	}

	@Override
	public List<Product> findAllOrderByPriceNative() {
		return em.createNativeQuery("SELECT * FROM products ORDER BY price ASC", Product.class).getResultList();
	}

	@Override
	@Transactional
	public void deleteById(Integer id) {
		Product managed = em.find(Product.class, id);
		if (managed != null)
			em.remove(managed);
	}
}
